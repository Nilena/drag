import { Component, ElementRef, OnInit } from '@angular/core';

import {globalVariables} from './../app/shared/constants/globals'
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'miplanit';
   constructor( private router            : Router,
    private elm               : ElementRef,){
    
   }
   ngOnInit() {
    globalVariables.apiBaseUrl = this.elm.nativeElement.getAttribute('apiBaseUrl');
   }
}
