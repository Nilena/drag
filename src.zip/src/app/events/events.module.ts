import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DragDropModule } from '@angular/cdk/drag-drop';


import { EventPageComponent } from './components/event-page/event-page.component';
import { EventFormComponent } from './components/event-form/event-form.component';

import { BsDatepickerModule, BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { MomentTimezonePickerModule } from 'moment-timezone-picker';
import { EventsRoutingModule } from './events-routing.module';
import { SharedModule } from '../shared/shared.module';

//llzz


@NgModule({
  declarations: [
    EventPageComponent,
    EventFormComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    BrowserAnimationsModule,
    EventsRoutingModule,
    BsDatepickerModule.forRoot(),
    MomentTimezonePickerModule,
    DragDropModule,
    SharedModule,
  ],
  exports:[EventsRoutingModule,EventFormComponent,EventPageComponent],
  providers: [BsDatepickerConfig],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
 
})
export class EventsModule { }
