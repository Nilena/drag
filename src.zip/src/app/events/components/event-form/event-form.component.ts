import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { Router } from '@angular/router';

import * as moment from 'moment';
import * as _moment from 'moment-timezone';

import { AuthService } from '../../../auth/services/auth.service';
import { EventService } from '../../service/event.service'
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { globalVariables } from 'src/app/shared/constants/globals';
import { TimeZoneService } from 'src/app/shared/services/time-zone.service';


@Component({
  selector: 'app-event-form',
  templateUrl: './event-form.component.html',
  styleUrls: ['./event-form.component.css']
})

export class EventFormComponent implements OnInit {
  eventDurInMin: any;
  concatCount: any;
  totalSlots: Array<any> = [];
  eventSlots: Array<any> = [];
  isMobileView: any;
  resStatus: any;
  noTimeAvailable: boolean = false;

  constructor(
    private router: Router,
    private authService: AuthService,
    private eventService: EventService,
    private timeZon: TimeZoneService
  ) { }

  @ViewChild('dragEvent') dragEvent: any;
  @ViewChild('dragContainer') dragContainer: any;
  @Input('cdkDropListAutoScrollStep') autoScrollStep: number | undefined;
  @Input('cdkDropListAutoScrollDisabled') autoScrollDisabled: boolean = false;


  selectedDate = new Date();
  disabledDays: any;
  eventInfo: any;
  myStartTime: any;
  myEndTime: any;
  drag: any;
  eventName: any;
  eventDuration: any
  minDate: any;
  maxDate: any;
  timeZone: any;
  location: any;
  description: any;
  userId: any;
  startTime: any;
  endTime: any;
  reserveSlots: any;
  time: Array<any> = [];
  startTimeAry: Array<any> = [];
  filteredSlots: Array<any> = []
  defaultDuration: any;
  containerHeight: any;
  dragElDeHeight: any;
  dragElMinHeight: any;
  calBkLinkShareId: any;
  toasterStatus: any
  toasterMessage: any
  status: any = false

  ngOnInit(): void {
    this.findDeviceWidth();
    this.defaultDuration = 15
    this.toasterStatus = false;

    if (this.authService.tokenURL == undefined || this.authService.tokenURL == '')
      this.router.navigate(['/', 'pagenotfound'])

    this.autoScrollStep = Number(50);

    this.authService.getEventDetails((res: any) => {
      if (res?.Status === 'OK') {
        this.eventInfo = res;
        this.eventName = this.eventInfo.data.eventName
        this.timeZone = _moment.tz.guess();
        globalVariables.header.miplanitauthtoken = this.eventInfo.data.authToken
        this.eventDuration = moment.utc().startOf('day').add({ minutes: this.eventInfo.data.duration }).format('HH:mm') + ' hr'

        this.eventDurInMin = this.eventInfo.data.duration
        this.concatCount = this.eventDurInMin / this.defaultDuration
        this.minDate = new Date(this.calZoneDate(this.eventInfo.data.startDate, this.eventInfo.data.startTime).format('MM/DD/YYYY'));
        this.maxDate = new Date(this.calZoneDate(this.eventInfo.data.endDate, this.eventInfo.data.endTime).format('MM/DD/YYYY'));
        this.location = res.data.location;
        this.description = res.data.description;
        this.userId = res.data.userId;
        this.startTime = _moment.utc(this.eventInfo.data.startTime, 'hh:mm:ss A').tz(this.timeZone).format('hh:mm A')
        this.endTime = _moment.utc(this.eventInfo.data.endTime, 'hh:mm:ss A').tz(this.timeZone).format('hh:mm A')
        if (res.data?.excludedWeekDays) {
          for (let i = 0; i < res.data.excludedWeekDays?.length; i++) {
            res.data.excludedWeekDays[i] = res.data.excludedWeekDays[i] - 1;
          }
          this.disabledDays = res.data.excludedWeekDays
        }
        this.dragElDeHeight = '91px'
        this.dragElMinHeight = ((this.dragElDeHeight.slice(0, -2) / 60));
        this.containerHeight = this.dragContainer.nativeElement.scrollHeight;
        this.calBkLinkShareId = this.eventInfo.data.calBkLinkShareId;
      }
    });

  }

  onResize(event: any) {
    this.findDeviceWidth();
  }

  findDeviceWidth() {
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))
      this.isMobileView = true;
    else
      this.isMobileView = false;
  }

  updateCalendar(zone: any): void {

    if (this.timeZone) {
      this.timeZone = zone.nameValue;
      this.minDate = new Date(this.calZoneDate(this.eventInfo.data.startDate, this.eventInfo.data.startTime).format('MM/DD/YYYY'));
      this.maxDate = new Date(this.calZoneDate(this.eventInfo.data.endDate, this.eventInfo.data.endTime).format('MM/DD/YYYY'));
      this.selectedDate = this.minDate;
      if (this.disabledDays) {
        let day = this.calZoneDate(this.eventInfo.data.startDate, this.eventInfo.data.startTime);
        if (day.format('dddd') === 'Saturday') {
          this.selectedDate = new Date(day.add(2, 'days').format('MM/DD/YYYY'));
        }
        else if (day.format('dddd') === 'Sunday') {
          this.selectedDate = new Date(day.add(1, 'days').format('MM/DD/YYYY'));
        }
      } else
        this.selectedDate = this.minDate;
        if(moment(this.minDate).isBefore(moment())){
          this.minDate=new Date(moment().format('MM/DD/YYYY'))
        }
        

    }
    this.updateReservation();
  }

  updateReservation() {
    let checkDate = new Date(this.selectedDate)
    let Obj = {
      field: 'ListUserCalendarEvents',
      arguments: {
        userId: this.userId,
        checkStartDate: this.calToUtcDate(moment(checkDate).format('YYYY-MM-DD'), '00:00:00').format('YYYY-MM-DD HH:mm:ss'),
        checkEndDate: this.calToUtcDate(moment(checkDate).format('YYYY-MM-DD'), '23:59:59').format('YYYY-MM-DD HH:mm:ss')
      }
    }
    if (this.userId != undefined) {
      this.eventService.getSlotsByDate(Obj, (res: any) => {
        if (res.Status === 'OK') {
          this.reserveSlots = res;
          this.slotsByZone()
        }
      });
    }
  }

  slotsByZone() {
    // this.createTFHSlots();//del
    let apiSlots = <any>[]
    let selectedDate = moment(this.selectedDate).format('YYYY-MM-DD');
    let dayStart = moment(moment(this.selectedDate).format('YYYY-MM-DD') + ' 12:00 AM', 'YYYY-MM-DD hh:mm A');
    let dayEnd = moment(moment(this.selectedDate).format('YYYY-MM-DD') + ' 11:59 PM', 'YYYY-MM-DD hh:mm A');
    this.startTime = _moment.utc(this.eventInfo.data.startTime, 'hh:mm:ss A').tz(this.timeZone).format('hh:mm A')
    this.endTime = _moment.utc(this.eventInfo.data.endTime, 'hh:mm:ss A').tz(this.timeZone).format('hh:mm A');
    this.reserveSlots.data && this.reserveSlots.data.forEach((d: any) => {
      let startDt = this.calZoneDate(moment(d.startDate, 'YYYY-MM-DD').format('MM/DD/YYYY'), moment(d.startTime, 'HH:mm:ss'));
      let endDt = this.calZoneDate(moment(d.endDate, 'YYYY-MM-DD').format('MM/DD/YYYY'), moment(d.endTime, 'HH:mm:ss'));
      let createdTimeZone = this.timeZone;
      if (d?.recurringTimeZone)
        createdTimeZone = this.timeZon.getTimeZone(d?.recurringTimeZone);
      if (d.originalStartTimeZone == null || d.originalStartTimeZone == 'tzone://Microsoft/Custom') {
        createdTimeZone = this.timeZone;
      } else
        createdTimeZone = this.timeZon.getTimeZone(d.originalStartTimeZone,);

      let createdDate = _moment.utc(d.actualStartDateTime, 'YYYY-MM-DD HH:mm:ss').tz(createdTimeZone);
      let startDate = _moment.utc(d.startDate + ' ' + d.startTime, 'YYYY-MM-DD HH:mm:ss').tz(createdTimeZone);
      let endDate = _moment.utc(d.endDate + ' ' + d.endTime, 'YYYY-MM-DD HH:mm:ss').tz(createdTimeZone);


      let offSetStartDST = createdDate.utcOffset() - startDate.utcOffset();
      let offSetEndDST = createdDate.utcOffset() - endDate.utcOffset();

      startDt.add(offSetStartDST, "minutes");
      endDt.add(offSetEndDST, "minutes");
      if (selectedDate === startDt.format('YYYY-MM-DD')) {
        if (startDt.isBefore(dayStart))
          startDt = dayStart;
        if (moment(endDt.format('YYYY-MM-DD hh:mm A')).isAfter(moment(dayEnd, 'YYYY-MM-DD hh:mm A'))) {
          endDt = dayEnd;
        }
        let Obj = {
          // eventId: d.eventId,
          startDate: startDt.format('YYYY-MM-DD'),
          endDate: endDt.format('YYYY-MM-DD'),
          startTime: startDt.format('hh:mm A'),
          endTime: endDt.format('hh:mm A'),
          height: 0 + 'px',
          type: 'busy'
        }
        apiSlots.push(Obj);
      }
    });

    apiSlots = this.sortSlots(apiSlots);
    this.filterApiSlots(apiSlots);
  }

  filterApiSlots(apiSlots: any) {
    this.filteredSlots.splice(0, this.filteredSlots.length)
    let selectedDate = moment(this.selectedDate, 'YYYY-MM-DD');//selected Date
    let dayStart = moment('12:00 AM', 'hh:mm A');
    let dayEnd = moment('11:59 PM', 'hh:mm A');

    let startTime = moment(this.startTime, 'hh:mm A');
    let endTime = moment(this.endTime, 'hh:mm A');

    ///////////1-day event/////////////////////////


    if (endTime.isAfter(startTime)) {
      let freeTimeEnd1 = moment()
      let freeTimeEnd2 = moment()

      apiSlots = apiSlots.filter((el: any) => {
        if (moment(el.startTime, 'hh:mm A').isBefore(startTime) && moment(el.endTime, 'hh:mm A').isAfter(startTime))
          return el
        if (moment(el.startTime, 'hh:mm A').isBefore(endTime) && moment(el.endTime, 'hh:mm A').isAfter(endTime))
          return el
        if (moment(el.startTime, 'hh:mm A').isSameOrAfter(startTime) && moment(el.endTime, 'hh:mm A').isSameOrBefore(endTime))
          return el
      });

      freeTimeEnd1 = startTime
      freeTimeEnd2 = endTime
      if (moment(apiSlots[0]?.startTime, 'hh:mm A').isBefore(startTime) && moment(apiSlots[0]?.endTime, 'hh:mm A').isAfter(startTime)) {
        freeTimeEnd1 = moment(apiSlots[0].startTime, 'hh:mm A');
      }
      if (moment(apiSlots[0]?.startTime, 'hh:mm A').isBefore(endTime) && moment(apiSlots[0]?.endTime, 'hh:mm A').isAfter(endTime)) {
        freeTimeEnd2 = moment(apiSlots[0].startTime, 'hh:mm A');
      }
      this.createTFHSlots();
      this.changeType(dayStart, freeTimeEnd1, 'free');
      this.changeType(freeTimeEnd2, dayEnd, 'free');

      apiSlots.forEach((item: any) => {
        this.changeType(moment(item.startTime, 'hh:mm A'), moment(item.endTime, 'hh:mm A '), 'busy');
      });
    }

    ///////////////////////2 day event////////////////////////

    if (startTime.isAfter(endTime) || (this.disabledDays?.length > 0 && selectedDate.format('dddd') == 'Monday')) {
      let freeTimeEnd1 = moment()
      let freeTimeEnd2 = moment()
      let startDate = moment(this.minDate, 'YYYY-MM-DD')
      let endDate = moment(this.maxDate, 'YYYY-MM-DD')

      if (selectedDate.format('YYYY-MM-DD') == startDate.format('YYYY-MM-DD')) {
        apiSlots = apiSlots.filter((el: any) => {
          if ((moment(el.endTime, 'hh:mm A').isAfter(startTime)
            && moment(el.endTime, 'hh:mm A').isSameOrBefore(dayEnd))
            || moment(el.endTime, 'hh:mm A').isSame(dayStart))
            return el
        });

        freeTimeEnd1 = moment(this.startTime, 'hh:mm A');
        if (moment(apiSlots[0]?.startTime, 'hh:mm A').isBefore(startTime)) {
          freeTimeEnd1 = moment(apiSlots[0].startTime, 'hh:mm A');
        }
        this.createTFHSlots();
        apiSlots && apiSlots.forEach((item: any) => {
          this.changeType(moment(item.startTime, 'hh:mm A'), moment(item.endTime, 'hh:mm A '), 'busy');
        });

        this.changeType(dayStart, freeTimeEnd1, 'free');

      } else if (selectedDate.isAfter(startDate) && selectedDate.isBefore(endDate)) {
        let Array1 = apiSlots.filter((el: any) => {
          if (moment(el.startTime, 'hh:mm A').isSameOrAfter(dayStart) && moment(el.endTime, 'hh:mm A').isSameOrBefore(endTime))
            return el;
          if (moment(el.startTime, 'hh:mm A').isBefore(endTime) && moment(el.endTime, 'hh:mm A').isAfter(endTime))
            return el;
        });

        let Array2 = apiSlots.filter((el: any) => {
          if ((moment(el.endTime, 'hh:mm A').isAfter(startTime) && moment(el.endTime, 'hh:mm A').isSameOrBefore(dayEnd))
            || (moment(el.startTime, 'hh:mm A').isAfter(startTime) && moment(el.endTime, 'hh:mm A').isBefore(startTime)))
            return el
        });

        freeTimeEnd1 = startTime;
        freeTimeEnd2 = endTime;

        if (moment(Array1[0]?.startTime, 'hh:mm A').isBefore(endTime) && (moment(Array1[0]?.endTime, 'hh:mm A').isAfter(endTime)))
          freeTimeEnd1 = moment(Array1[0].endTime, 'hh:mm A')
        if (moment(Array2[0]?.startTime, 'hh:mm A').isBefore(startTime) && (moment(Array2[0]?.endTime, 'hh:mm A').isAfter(startTime)))
          freeTimeEnd2 = moment(Array2[Array2.length - 1].startTime, 'hh:mm A')
        this.createTFHSlots();
        apiSlots.forEach((item: any) => {
          this.changeType(moment(item.startTime, 'hh:mm A'), moment(item.endTime, 'hh:mm A '), 'busy');
        });
        this.changeType(freeTimeEnd2, freeTimeEnd1, 'free');
      } else {
        apiSlots = apiSlots?.filter((el: any) => {
          if (moment(el.startTime, 'hh:mm A').isSameOrAfter(dayStart) && moment(el.endTime, 'hh:mm A').isSameOrBefore(endTime))
            return el;
          if (moment(el.startTime, 'hh:mm A').isBefore(endTime) && moment(el.endTime, 'hh:mm A').isAfter(endTime))
            return el
        });
        freeTimeEnd1 = endTime;
        if (moment(apiSlots[0]?.startTime, 'hh:mm A').isBefore(endTime) && (moment(apiSlots[0]?.endTime, 'hh:mm A').isAfter(endTime))) {
          freeTimeEnd1 = moment(apiSlots[apiSlots.length - 1].endTime, 'hh:mm A')
        }
        this.createTFHSlots();

        apiSlots.forEach((item: any) => {
          this.changeType(moment(item.startTime, 'hh:mm A'), moment(item.endTime, 'hh:mm A '), 'busy');
        });
        this.changeType(freeTimeEnd1, dayEnd, 'free');
      }
    }
    this.eventSlots = apiSlots;
    this.createStartTimeArray();
    this.autoSelectMyEvent();
    setTimeout(() => {
      let dragElem = document.getElementsByClassName('selected')
      dragElem[0]?.scrollIntoView({ behavior: "smooth" });
    }, 1000);

  }



  changeType(start: any, end: any, type: any) {
    this.filteredSlots.forEach(item => {
      // if (moment(item.endTime, 'hh:mm A').isSame(moment('11:59 PM', 'hh:mm A')))
      //   item.type = 'free'
      if (moment(item.startTime, 'hh:mm A').isSameOrAfter(start) && moment(item.endTime, 'hh:mm A').isSameOrBefore(end)) {
        item.type = type;
      }
      if (moment(item.startTime, 'hh:mm A').isBefore(end) && moment(item.endTime, 'hh:mm A').isAfter(end))
        item.type = type;
    });
  }

  selectSlot(item: any) {


    let index = this.filteredSlots.indexOf(item);
    for (let i = index; i <= index + this.concatCount - 1; i++) {
      //  if (moment(this.filteredSlots[i].startTime, 'hh:mm A').isAfter(moment(this.filteredSlots[i].endTime, 'hh:mm A'))) return
      if (this.filteredSlots[i]?.type == 'busy' || this.filteredSlots[i]?.type == 'free') {
        return
      }
    }

    if (item.type != '')
      return
    let startTime = item.startTime
    this.updateEndTime(startTime)
  }

  updateEndTime(item: any) {
    if(this.myStartTime=='')return;
    let dayEnd = moment(moment(this.selectedDate).format('YYYY-MM-DD') + ' 12:00 AM');
    let start = moment(moment(this.selectedDate).format('YYYY-MM-DD') + ' ' + item)

    /* if (moment(this.endTime, 'hh:mm A').isAfter(moment(this.startTime, 'hh:mm A'))) {
       if (start.add(this.concatCount * this.defaultDuration, 'minutes').isAfter(moment(this.endTime, 'hh:mm A')))
         return
     }
     else {
       if (moment(start).add(this.concatCount * this.defaultDuration, 'minutes').isAfter(dayEnd.add(1, 'day')))
         return
     }
     */
    this.myStartTime = moment(item, 'hh:mm A').format('hh:mm A')
    this.myEndTime = moment(item, 'hh:mm A').add(this.concatCount * this.defaultDuration, 'minutes').format('hh:mm A')
    let time = moment(item, 'hh:mm A').add(this.defaultDuration * this.concatCount, 'minutes').format('hh:mm A')
    this.filteredSlots = this.filteredSlots.filter(t => {
      if (t.type == 'selected' || t.type == 'hide') {
        t.type = ''
        t.height = this.defaultDuration * this.dragElMinHeight + 'px';
      }
      return t
    })


    this.filteredSlots = this.filteredSlots.filter(t => {
      if (t.startTime == item)
        t.type = 'selected'
      return t
    })
    let index = 0
    for (let i = 0; i < this.filteredSlots.length; i++) {
      if (this.filteredSlots[i]?.type == 'selected') {
        index = i
        this.filteredSlots[i].height = this.defaultDuration * this.concatCount * this.dragElMinHeight + 'px';
      }
    }
    for (let i = index + 1; i < index + this.concatCount; i++) {
      this.filteredSlots[i].type = 'hide'
    }
    return time
  }



  ////////////////////////////////////////////////////////////////////////////////
  //drag and drop
  ////////////////////////////////////////////////////////////////////////////////
  checkDrop(current: any, index: any): any {
    for (let i = current; i < current + this.concatCount - 1; i++) {
      if (this.filteredSlots[i]?.type != '') {
        return false
      }
      else return true
    }
  }

  drop(event: CdkDragDrop<string[]>) {

    let startTemp = ''
    let endTemp = ''
    let c = event.currentIndex;
    let p = event.previousIndex;
    c = c - this.concatCount + 1;

    if (c == p) return
    if (this.filteredSlots[c]?.type == 'free' || this.filteredSlots[c]?.type == 'busy')
      return
    if (c > p) {
      for (let i = c + 1; i <= c + this.concatCount - 1; i++) {

        //   if (moment(this.filteredSlots[i].startTime, 'hh:mm A').isAfter(moment(this.filteredSlots[i].endTime, 'hh:mm A'))) return
        if (this.filteredSlots[i]?.type == 'busy' || this.filteredSlots[i]?.type == 'free') {
          return
        }
      }
      this.filteredSlots.forEach((item) => {
        if (item.type == 'selected' || item.type == 'hide')
          item.type = ''
        item.height = this.defaultDuration * this.dragElMinHeight + 'px';
      })
      this.filteredSlots[c].type = "selected"
      this.filteredSlots[c].height = this.defaultDuration * this.concatCount * this.dragElMinHeight + 'px';
      for (let i = c + 1; i <= c + this.concatCount - 1; i++) {
        this.filteredSlots[i].type = 'hide'
      }

    } else if (p > c) {
      for (let i = c + 1; i <= c + this.concatCount - 1; i++) {
        //   if (moment(this.filteredSlots[i].startTime, 'hh:mm A').isAfter(moment(this.filteredSlots[i].endTime, 'hh:mm A'))) return
        if (this.filteredSlots[i]?.type == 'busy' || this.filteredSlots[i]?.type == 'free') {


          return
        }
      }

      this.filteredSlots.forEach((item) => {
        if (item.type == 'selected' || item.type == 'hide')
          item.type = ''
        item.height = this.defaultDuration * this.dragElMinHeight + 'px';
      })

      this.filteredSlots[c].type = "selected"
      this.filteredSlots[c].height = this.defaultDuration * this.concatCount * this.dragElMinHeight + 'px';
      for (let i = c + 1; i < c + this.concatCount; i++) {
        this.filteredSlots[i].type = 'hide'
      }

    }
    this.filteredSlots[c].type = 'selected'
    this.filteredSlots.forEach((item) => {
      if (item.type == 'selected') {
        this.myStartTime = item.startTime;
        this.myEndTime = moment(this.myStartTime, 'hh:mm A').add(this.defaultDuration * this.concatCount, 'minutes').format('hh:mm A')
      }
    })
    this.drag == false

  }

  showDragDrop() {

    if (this.isMobileView == true) {
      this.drag = true
    } else
      this.drag = false
    setTimeout(() => {
      let dragElem = document.getElementsByClassName('selected')
      dragElem[0].scrollIntoView({ behavior: "smooth" });
    }, 1000);

  }
  closeDragDrop() {
    this.drag = false
  }
  cancelForm() {
    this.router.navigate(['/', 'pagenotfound']);
    this.authService.tokenURL = ''
  }
  autoSelectMyEvent() {
    if(this.startTimeAry.length==0)return
     for (let i = 0; i < this.filteredSlots.length; i++) {
       if (this.filteredSlots[i]?.type == 'selected')
         return
     }

    let curDate = moment().format('YYYY-MM-DD')
    let selDate = moment(this.selectedDate, 'YYYY-MM-DD');
    if (selDate.isAfter(moment(curDate, 'YYYY-MM-DD'))) {
      if (this.filteredSlots.length > 0) {
        const f = this.filteredSlots.find(e => e.type == '');
        let index = this.filteredSlots.indexOf(f);
        let flag;
        for (let i = index; i < this.filteredSlots?.length - this.concatCount; i++) {
          flag = 0;
          for (let j = i; j < i + this.concatCount; j++) {   
            if (this.filteredSlots[j]?.type == 'busy')
              flag = 1
          }
          if (flag == 0) {
            this.filteredSlots[i].height = this.defaultDuration * this.concatCount * this.dragElMinHeight + 'px';   
            for (let j = i; j < i + this.concatCount; j++)
              if (j == i) {
                this.filteredSlots[j].type = 'selected'   
              } else
                this.filteredSlots[j].type = 'hide';
            this.myStartTime = this.filteredSlots[i].startTime
            i = this.filteredSlots.length
          }
        }
        this.myEndTime = moment(this.myStartTime, 'hh:mm A').add(this.defaultDuration * this.concatCount, 'minutes').format('hh:mm A')
      }
      return
    }

    for (let i = 0; i < this.startTimeAry.length; i++) {
      let currentTime = moment();
      if (this.startTimeAry[i] == currentTime.format('hh:mm A')) {
        this.myStartTime = this.startTimeAry[i];
        i = this.startTimeAry.length;
      }
      else {
        currentTime = currentTime.add(15, 'minutes');
        currentTime.minutes(Math.floor(currentTime.minutes() / 15) * 15);
        if (moment(this.startTimeAry[i], 'hh:mm A').isAfter(currentTime)) {
          this.myStartTime = this.startTimeAry[i];
          i = this.startTimeAry.length;
        }
        if (moment(this.startTimeAry[i], 'hh:mm A').isSame(currentTime)) {

          this.myStartTime = this.startTimeAry[i];
          i = this.startTimeAry.length;
        }
        else if (i == this.startTimeAry.length - 1) {
          this.myStartTime = this.startTimeAry[i];
          i = this.startTimeAry.length;
          //  console.log(this.selectedDate, currentTime);

          //  this.noTimeAvailable=true;
        }

      }

    }
    this.updateEndTime(this.myStartTime)
    this.myEndTime = moment(this.myStartTime, 'hh:mm A').add(this.defaultDuration * this.concatCount, 'minutes').format('hh:mm A')


  }
  createStartTimeArray() {
    this.startTimeAry.splice(0, this.startTimeAry.length)
    let f = 1;
    for (let i = 0; i < this.filteredSlots?.length-this.concatCount+1; i++) {
      f = 1;
      for (let j = i; j <= i + this.concatCount - 1; j++) {
        if (this.filteredSlots[j]?.type == 'busy' || this.filteredSlots[j]?.type == 'free') {
          f = 0
        }
      }
      if (f == 1)
        this.startTimeAry.push(this.filteredSlots[i].startTime)
    }
  }


  findEnd(time: any) {
    let t = moment(time, 'hh:mm A').add(this.defaultDuration * this.concatCount, 'minutes').format('hh:mm A')
    return t;
  }

  submit() {

    let s = this.selectedDate;
    let start = this.myStartTime
    let end = this.myEndTime
    let currentDate = moment().format('YYYY-MM-DD');
    if (moment(s, 'YYYY-MM-DD').isBefore(moment(currentDate, 'YYYY-MM-DD'))) {
      this.noTimeAvailable = true
    } else if (moment(s, 'YYYY-MM-DD').isSame(moment(currentDate, 'YYYY-MM-DD'))) {
      if (moment(start, 'hh:mm A').isBefore(moment(moment(), 'hh:mm A')))
        this.noTimeAvailable = true
      else
        this.noTimeAvailable = false
    }
    else {
      this.noTimeAvailable = false;
    }
    if (this.noTimeAvailable == true) {
      this.toasterStatus = true;
      this.resStatus = 'error';
      this.toasterMessage = 'Pick upcoming TimeSlots';
      setTimeout(() => {
        this.toasterStatus = false;
      }, 2000);
      return
    }
    if (start == undefined || end == undefined) {
      return
    }
    let Obj = {
      "calBkLinkShareId": this.calBkLinkShareId,
      "startDate": moment(s, 'YYYY-MM-DD').format('YYYY-MM-DD'),
      "endDate": moment(s, 'YYYY-MM-DD').format('YYYY-MM-DD'),
      "startTime": moment(this.calToUtcDate(moment(s).format('YYYY-MM-DD'), moment(start, 'hh:mm A').format('HH:mm:ss')), 'YYYY-MM-DD hh:mm A').format('HH:mm:ss'),
      "endTime": moment(this.calToUtcDate(moment(s).format('YYYY-MM-DD'), moment(end, 'hh:mm A').format('HH:mm:ss')), 'YYYY-MM-DD hh:mm A').format('HH:mm:ss')
    }
    this.eventService.submitReservation(Obj, (res: any) => {
      let response = res;
      this.toasterStatus = true
      this.resStatus = response.Status;
      this.toasterMessage = response.Message;
      if (response) {

        setTimeout(() => {
          this.toasterStatus = false;
          this.status = true
        }, 2500);

        setTimeout(() => {
          this.status = false;
          this.router.navigate(['/', 'linkExpired']);
        }, 4000);
      }
    });
  }
  busySlot(item: any) {
    for (let i = 0; i < this.eventSlots.length; i++) {
      if (this.eventSlots[i].startTime == item.startTime) {
        return this.eventSlots[i].startTime + ' - ' + this.eventSlots[i].endTime + ' (busy)'
      }
    }
    return ''
  }
  createTFHSlots() {
    let dayStart = moment('12:00 AM', 'hh:mm A');
    let pixel = 0;
    let speCase;
    let totalPixel = 1440 * this.dragElMinHeight;
    while (pixel <= totalPixel - this.defaultDuration * this.dragElMinHeight) {
      (pixel == totalPixel - (this.defaultDuration * this.dragElMinHeight)) ? speCase = 1 : speCase = 0
      pixel = pixel + this.defaultDuration * this.dragElMinHeight;
      let Obj = {
        //endDate: selectedDate.format('YYYY-MM-DD'),
        //startDate: selectedDate.format('YYYY-MM-DD'),
        startTime: dayStart.format('hh:mm A'),
        //eventId: null,
        height: this.defaultDuration * this.dragElMinHeight + 'px',
        endTime: dayStart.add(this.defaultDuration - speCase, 'minutes').format('hh:mm A'),
        type: ''
      }
      this.filteredSlots.push(Obj)
    }
  }

  sortSlots(list: any) {
    return list.sort((a: any, b: any) => {
      return moment(a.startTime, 'hh:mm A').diff(moment(b.startTime, 'hh:mm A'));
    })
  }
  calZoneDate(d: any, t: any) {
    if (this.timeZone == 'Asia/Calcutta') this.timeZone = 'Asia/Kolkata';
    let dt = d + ' ' + moment(t, 'h:mm:ss A').format("HH:mm");
    return _moment.utc(dt, 'MM/DD/YYYY HH:mm').tz(this.timeZone.toString());
  }
  calToUtcDate(d: any, t: any) {
    return _moment.tz(d + ' ' + t, 'YYYY-MM-DD hh:mm A', this.timeZone).utc()
  }
  checkDragable(item: any) {
    if (item.type != 'selected')
      return true;
    return false;
  }
}
