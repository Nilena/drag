import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { apiList } from '../../shared/constants/apilist'
import { globalVariables } from '../../shared/constants/globals'

@Injectable({
  providedIn: 'root'
})
export class EventService {

  constructor(
    private http: HttpClient,
  ) { }

  getSlotsByDate(data: any, callBack: any,) {
    let url = globalVariables.apiBaseUrl + apiList.events.sendDate + '?userId=' + data.arguments.userId + '&checkStartDate=' + data.arguments.checkStartDate + '&checkEndDate=' + data.arguments.checkEndDate;
    const promise = new Promise((resolve, reject) => {
      this.http.get(url, {
        headers: globalVariables.header
      })
        .toPromise()
        .then(res => {
          if (res) callBack(res)
        })
       .catch(res => {
       })
    })
    return promise;
  }
  submitReservation(data: any, callBack: any,) {
   // let url = globalVariables.apiBaseUrl + apiList.events.submitReservation + '?calBkLinkShareId=' + data.calBkLinkShareId + '&startDate=' + data.startDate + '&endDate=' + data.endDate + '&startTime=' + data.startTime + '&endTime=' + data.endTime;
   let url= globalVariables.apiBaseUrl + apiList.events.submitReservation;
   console.log(url);

    const promise = new Promise((resolve, reject) => {
      this.http.post(url,data, {
        headers: globalVariables.header,
        
      })
        .toPromise()
        .then(res => {
          if (res) callBack(res)
        })
      // .catch(res => {
      //   console.log('error');
      // })
    })
    return promise;
  }
}

