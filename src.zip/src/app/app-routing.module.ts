import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthComponent } from './auth/components/auth/auth.component';
import { PagenotfoundComponent } from './auth/components/pagenotfound/pagenotfound.component';
import { EventsModule } from './events/events.module';
import { EventPageComponent } from './events/components/event-page/event-page.component';
import { LinkExpiredComponent } from './auth/components/link-expired/link-expired.component';

const routes: Routes = [
  {
    path:'auth/:id',
    component:AuthComponent
  },
  {
    path:'pagenotfound',
    component:PagenotfoundComponent
  },
  {
    path:'linkExpired',
    component:LinkExpiredComponent
  },
  {
    path:'event',
    component:EventPageComponent,
    loadChildren:()=>import('./events/events-routing.module').then(m=>m.EventsRoutingModule)
  },
  {
    path:' ',
    redirectTo:'pagenotfound',
    pathMatch:'full'
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes,),EventsModule],
  //{ useHash: true, relativeLinkResolution: 'legacy' }
  exports: [RouterModule]
})
export class AppRoutingModule { }
