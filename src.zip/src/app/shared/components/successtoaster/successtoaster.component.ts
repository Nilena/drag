import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-successtoaster',
  templateUrl: './successtoaster.component.html',
  styleUrls: ['./successtoaster.component.css']
})
export class SuccesstoasterComponent implements OnInit {

  constructor() { }
@Input('status')status:any
@Input('toasterMessage')toasterMessage:any
  ngOnInit(): void {
    
  }

}
