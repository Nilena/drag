import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccesstoasterComponent } from './successtoaster.component';

describe('SuccesstoasterComponent', () => {
  let component: SuccesstoasterComponent;
  let fixture: ComponentFixture<SuccesstoasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuccesstoasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SuccesstoasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
