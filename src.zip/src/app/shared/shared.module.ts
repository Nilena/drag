import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SuccesstoasterComponent } from './components/successtoaster/successtoaster.component';
import { LoaderComponent } from './components/loader/loader.component';



@NgModule({
  declarations: [
    SuccesstoasterComponent,
    LoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[SuccesstoasterComponent,LoaderComponent]
})
export class SharedModule { }
