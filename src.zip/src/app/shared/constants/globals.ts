export let globalVariables: any = {
	apiBaseUrl : 'https://3cn4g3qms4.execute-api.us-east-1.amazonaws.com/prd',
	localUrl:'http://localhost:4200',
	header: {
		'Access-Control-Allow-Headers':'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
		'Access-Control-Allow-Origin':'*',
		'Access-Control-Allow-Methods':'GET,OPTIONS',
		'miplanitauthtoken': ''
	  }
};