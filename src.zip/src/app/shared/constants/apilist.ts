export const apiList:any ={
    auth:{
        linkExpiry:'/booking-link/valid',
    },
    events:{
        sendDate:'/event/day-view',
        submitReservation:'/booking-link/authorize'
    }
}