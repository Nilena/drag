import { Injectable } from '@angular/core';
import {  HttpClient } from '@angular/common/http';
import { apiList } from '../../shared/constants/apilist'
import { globalVariables } from '../../shared/constants/globals'
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(
    private router: Router,
    private http: HttpClient,
  ) { }

  tokenURL: any;
ngOnInit(){
  
 
}

  getEventDetails(callBack:any) {
 let url = globalVariables.apiBaseUrl + apiList.auth.linkExpiry + '?url=' + this.tokenURL;
const promise = new Promise((resolve, reject) => {
      this.http.get(url, {
        headers: globalVariables.header
      })
        .toPromise()
        .then(res => {
          if (res) {
            callBack(res)}
        })
    })
    return promise;
  }

}
