import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthRoutingModule } from './auth-routing.module';
import { AuthComponent } from './components/auth/auth.component';
import { PagenotfoundComponent } from './components/pagenotfound/pagenotfound.component';
import { SharedModule } from '../shared/shared.module';
import { LinkExpiredComponent } from './components/link-expired/link-expired.component';


@NgModule({
  declarations: [
    AuthComponent,
    PagenotfoundComponent,
    LinkExpiredComponent
  ],
  imports: [
    CommonModule,
    AuthRoutingModule,
    SharedModule
  ],
  exports:[AuthRoutingModule]
})
export class AuthModule { }
