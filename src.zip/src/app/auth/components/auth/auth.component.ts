import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import * as moment from 'moment';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {

  constructor(
    private router: Router,
    private authService: AuthService
  ) { }

  status: any;
  ngOnInit(): void {
    this.status = true;
    const url = window.location.origin + this.router.url;
    this.authService.tokenURL = url;
    this.authService.getEventDetails((res: any) => {
      if (res?.Status === 'OK') {
        this.status = false;
        let currentDT=moment()
        let endDT=moment(res.data.endTime+' '+res.data.endDate,'hh:mm:ss A MM/DD/YYYY');
        if(currentDT.isAfter(endDT)){
          this.router.navigate(['/', 'linkExpired']);
        }else
        this.router.navigate(['/', 'event'])
      } else {
        this.status = false;
        this.router.navigate(['/', 'linkExpired']);
      }
    });
  }
}
